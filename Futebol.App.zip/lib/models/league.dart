class League {
  final int id;
  final String name;
  final String logo;

  League({required this.id, required this.name, required this.logo});

  factory League.fromJson(Map<String, dynamic> json) {
    return League(
      id: json['league']['id'],
      name: json['league']['name'],
      logo: json['league']['logo'],
    );
  }
}
