import 'package:flutter/material.dart';
import '../models/team.dart';
import 'team_detail_screen.dart';

class TeamListScreen extends StatefulWidget {
  final int leagueId;
  final String leagueName;

  TeamListScreen({required this.leagueId, required this.leagueName});

  @override
  _TeamListScreenState createState() => _TeamListScreenState();
}

class _TeamListScreenState extends State<TeamListScreen> {
  late Future<List<Team>> teams;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.leagueName)),
      body: FutureBuilder<List<Team>>(
        future: teams,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Erro: ${snapshot.error}'));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return Center(child: Text('Nenhum time encontrado'));
          } else {
            return ListView.builder(
              itemCount: snapshot.data!.length,
              itemBuilder: (context, index) {
                final team = snapshot.data![index];
                return ListTile(
                  leading: Image.network(team.logo, width: 40),
                  title: Text(team.name),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => TeamDetailScreen(team: team),
                      ),
                    );
                  },
                );
              },
            );
          }
        },
      ),
    );
  }
}
