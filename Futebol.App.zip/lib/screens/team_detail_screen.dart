import 'package:flutter/material.dart';
import '../models/team.dart';

class TeamDetailScreen extends StatelessWidget {
  final Team team;

  TeamDetailScreen({required this.team});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(team.name)),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.network(team.logo, height: 100),
            SizedBox(height: 20),
            Text(
              team.name,
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            Text("Mais detalhes em breve..."),
          ],
        ),
      ),
    );
  }
}
